package com.alan.springbootmicroserviceeureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMicroserviceEurekaApplicationTests {

	@Test
	void contextLoads() {
	}

}
