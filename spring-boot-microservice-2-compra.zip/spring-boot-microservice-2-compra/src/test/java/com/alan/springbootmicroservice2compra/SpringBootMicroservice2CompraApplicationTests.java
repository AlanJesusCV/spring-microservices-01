package com.alan.springbootmicroservice2compra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMicroservice2CompraApplicationTests {

	@Test
	void contextLoads() {
	}

}
