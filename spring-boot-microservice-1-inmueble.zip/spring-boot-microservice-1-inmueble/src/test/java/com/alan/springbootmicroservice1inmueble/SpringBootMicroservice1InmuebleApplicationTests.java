package com.alan.springbootmicroservice1inmueble;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootMicroservice1InmuebleApplicationTests {

	@Test
	void contextLoads() {
	}

}
